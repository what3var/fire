using System;
using System.Collections.Generic;
using System.Linq;
using fire.Ast;
using fire.Values;

namespace fire.Resolving
{
    public sealed class ResolverException : Exception
    {
        public int Line { get; }

        public ResolverException(string message, int line)
            : base($"{message} ({line})")
        {
            Line = line;
        }
    }

    /// <summary>Ergebnis eines Resolver-Laufs: alles, was der Evaluator (und später
    /// der Bytecode-Compiler) braucht, um nicht mehr per Namen suchen zu müssen.</summary>
    public sealed class ResolveResult
    {
        public required IReadOnlyDictionary<Expr, ResolvedRef> References { get; init; }
        public required IReadOnlyDictionary<string, ClassDecl> Classes { get; init; }
        public required int GlobalSlotCount { get; init; }
        public required IReadOnlyDictionary<string, ExternDecl> Externs { get; init; }

        /// <summary>`#noshadow` war IRGENDWO im Programm vorhanden (siehe
        /// Ast.NoShadowDirective/Resolver.ResolveFireStmt) - deaktiviert den
        /// Read-only-Globals-Snapshot in JEDEM `fire`-Block. Vom Compiler
        /// gelesen, um seinen `_globalSlotCount` effektiv auf 0 zu setzen
        /// (siehe dortige Doku) - das genügt allein schon, damit
        /// CompileFireStmt exakt wie vor Einführung des Snapshots
        /// kompiliert, ohne eigene bedingte Zweige dafür zu brauchen.</summary>
        public required bool NoShadowGlobals { get; init; }
    }

    /// <summary>
    /// Ein-Pass-Resolver über den AST. Zwei Aufgaben:
    ///
    /// 1) Variablen-Referenzen (IdentifierExpr, Zuweisungsziele) auf statische
    ///    Slots auflösen (Scope-Tiefe + Index), statt später zur Laufzeit per Name
    ///    durch die Scope-Kette zu suchen. Lambdas bekommen dabei absichtlich einen
    ///    Scope, dessen Parent direkt der globale Scope ist (nicht der lexikalisch
    ///    umschließende Scope) - das modelliert die eingeschränkte Lambda-
    ///    Sichtbarkeit (nur eigener Scope + global, SPEC 4.2) ganz von selbst, ohne
    ///    dass die Tiefen-Zählung beim Auflösen einen Sonderfall bräuchte.
    ///
    /// 2) Ein paar statische Prüfungen, die sich in diesem Pass anbieten:
    ///    - 'return' nur innerhalb einer Funktion/Methode/Lambda/Konstruktor/Destruktor.
    ///    - 'base' (als Ausdruck oder als Konstruktor-Initialisierer) nur innerhalb
    ///      einer Klasse, die tatsächlich eine Basisklasse hat.
    ///    - Referenzierte Klassennamen (Basisklasse, 'new X()', 'is of X', Typ-
    ///      Annotationen) müssen bekannt sein (deklariert oder die eingebaute
    ///      Basisklasse 'Exception').
    ///
    /// Bewusst NICHT geprüft: strikte Gültigkeit von 'this' (Lambdas können 'this'
    /// über 'on' auch außerhalb jeder Klasse sinnvoll nutzen, eine rein lexikalische
    /// Prüfung wäre hier eher einschränkend als hilfreich) - das überlassen wir der
    /// Laufzeit.
    /// </summary>
    public sealed class Resolver
    {
        /// <summary>Primitive/eingebaute Typnamen, die ValidateTypeName ohne
        /// Nachschlagen in `_classes` akzeptiert. 'lambda' steht für einen
        /// Lambda-Wert (Runtime.LambdaValue/ValueKind.Lambda), optional mit
        /// Signatur (`[RückgabeTyp] lambda[&lt;Param1,...,ParamN&gt;]`, siehe
        /// Ast.TypeRef.LambdaSignature/SPEC "Lambda-Typen mit Signatur") -
        /// Lambdas waren schon immer als WERTE übergebbar (dynamisch
        /// typisiert), aber bis jetzt gab es keinen Namen, um das (und ihre
        /// erwartete Parameterzahl) in einer Typ-Annotation auszudrücken.
        /// Bewusst NICHT 'func' (das Schlüsselwort, das einen Lambda-
        /// AUSDRUCK einleitet, `func (x) => ...`) - das würde mit der
        /// Ausdrucks-Syntax kollidieren: NextLooksLikeTypeThenName() prüft
        /// nur das AKTUELLE Token, ein alleinstehendes 'func(x) => ...' als
        /// Anweisung würde dann fälschlich als Beginn einer typisierten
        /// Deklaration gelesen (Typname 'func', erwarteter Name als
        /// nächstes) statt als Lambda-Ausdruck. 'lambda' selbst ist nur ein
        /// PLAIN Bezeichner (kein Keyword-Token, siehe Parser.
        /// NextLooksLikeTypeThenName), kollidiert also nur, wenn jemand
        /// tatsächlich etwas 'lambda' nennt - anders als 'func' kein
        /// bestehendes Sprachkonstrukt. Wie 'class' ist 'lambda' syntaktisch
        /// akzeptiert; ANDERS als sonstige Typ-Annotationen wird die
        /// Parameter-ANZAHL einer Signatur aber tatsächlich zur Laufzeit
        /// geprüft (VM.CheckLambdaSignature) - eine bewusste Ausnahme von
        /// SPEC 8.1 ("Typ-Annotationen nicht durchgängig geprüft"), weil
        /// sich das hier (anders als bei Klassen-Typen) mit vertretbarem
        /// Aufwand robust umsetzen ließ.</summary>
        private static readonly HashSet<string> PrimitiveTypeNames = new()
        {
            "bool", "int", "float", "char", "string", "class", "undefined", "lambda",
        };

        private readonly Dictionary<Expr, ResolvedRef> _refs = new(ReferenceEqualityComparer.Instance);
        private readonly Dictionary<string, ClassDecl> _classes = new();

        /// <summary>Wie Bytecode.Compiler.NamespaceResolver, aber für die
        /// Resolver-eigene Validierung (siehe ResolveNamespaceName/
        /// IsKnownClassName) - MUSS unabhängig existieren (nicht denselben
        /// Compiler-internen Typ wiederverwenden), da der Resolver mit
        /// ClassDecl statt RuntimeClass arbeitet und beide Schichten
        /// unabhängig voneinander laufen (der Compiler bekommt Klassen
        /// selbst erneut aus dem AST, nicht vom Resolver übernommen).
        /// `new X()`/`is of X`/`catch (e : X)` werden hier VOR dem
        /// eigentlichen Kompilieren bereits validiert (SPEC "Namespaces") -
        /// ohne dieselbe Auflösung hier würde ein unqualifizierter
        /// Namespace-Verweis schon an dieser Stelle als "unbekannte Klasse"
        /// abgelehnt, bevor der Compiler ihn je sehen könnte.</summary>
        private readonly Dictionary<string, List<(string Namespace, string Qualified)>> _bySimpleName = new();

        /// <summary>Die `#using`-Namen für TOP-LEVEL-Code (außerhalb jeder
        /// Klasse) - innerhalb einer Klasse gelten stattdessen deren EIGENE,
        /// gestempelte `Ast.ClassDecl.Usings` (siehe CurrentUsings/Parser.
        /// StampUsings) statt einer einzigen, programmweiten Liste - wichtig
        /// bei mehreren kombinierten Quelldateien (Parser.ParseMultiple),
        /// wo `#using` bewusst nur lokal für die eigene Datei gelten soll.</summary>
        private IReadOnlyList<string> _topLevelUsings = Array.Empty<string>();

        private void BuildNamespaceIndex()
        {
            foreach (var full in _classes.Keys)
            {
                int dot = full.LastIndexOf('.');
                if (dot < 0) continue;
                string ns = full[..dot];
                string simple = full[(dot + 1)..];
                if (!_bySimpleName.TryGetValue(simple, out var list))
                    _bySimpleName[simple] = list = new List<(string, string)>();
                list.Add((ns, full));
            }
        }

        private string? CurrentNamespace
        {
            get
            {
                if (_currentClass == null) return null;
                int dot = _currentClass.Name.LastIndexOf('.');
                return dot < 0 ? null : _currentClass.Name[..dot];
            }
        }

        /// <summary>Die für die AKTUELL aufgelöste Stelle geltenden
        /// `#using`-Namen - siehe Compiler.CurrentUsings für dieselbe Idee
        /// auf der Compiler-Seite.</summary>
        private IReadOnlyList<string> CurrentUsings => _currentClass?.Usings ?? _topLevelUsings;

        /// <summary>Löst `name` auf seinen vollqualifizierten Namen auf, WENN
        /// nötig - siehe Bytecode.Compiler.NamespaceResolver.Resolve für die
        /// genaue Regel (exakter Treffer > Geschwister im eigenen Namespace >
        /// `#using` > unverändert lassen).</summary>
        private string ResolveNamespaceName(string name)
        {
            if (IsKnownClassName(name)) return name;
            if (!_bySimpleName.TryGetValue(name, out var candidates)) return name;

            var currentNs = CurrentNamespace;
            if (currentNs != null)
                foreach (var (ns, full) in candidates)
                    if (ns == currentNs) return full;

            var activeUsings = CurrentUsings;
            foreach (var (ns, full) in candidates)
                if (activeUsings.Contains(ns)) return full;

            return name;
        }

        private readonly Dictionary<string, InterfaceDecl> _interfaces = new();
        private readonly Dictionary<string, ExternDecl> _externs = new();
        private readonly Dictionary<string, Dictionary<string, long>> _enums = new();
        private readonly HashSet<string> _nativeNames;
        private readonly HashSet<string> _tryableNativeNames;
        private readonly ResolverScope _globalScope = new(parent: null, isGlobal: true);

        private ResolverScope _current;
        private int _functionDepth;

        /// <summary>Siehe Ast.NoShadowDirective/ResolveResult.NoShadowGlobals
        /// - von Resolve() VOR jeder Statement-Auflösung in einem
        /// Vorab-Durchlauf gesetzt (wie bei Klassen/Enums/Externs), damit es
        /// unabhängig von der Position der `#noshadow`-Direktive im
        /// Quelltext gilt (auch für einen `fire`-Block, der VOR der
        /// Direktive im Quelltext steht).</summary>
        private bool _noShadowGlobals;

        /// <summary>Wie `_functionDepth`, aber für `break`/`continue`: Anzahl
        /// umschließender Schleifen (0 = kein `break`/`continue` gültig) bzw.
        /// `try`/`catch`/`finally`-Blöcke seit der letzten Schleife (>0 = ein
        /// `break`/`continue` hier müsste über eine try-Grenze hinweg
        /// springen - bewusst als Fehler abgelehnt, siehe ResolveTry-Doku).
        /// Beide werden beim Betreten einer neuen Funktion/Methode/Lambda
        /// GESICHERT UND AUF 0 ZURÜCKGESETZT (nicht einfach erhöht, wie
        /// `_functionDepth`) - eine Schleife der UMSCHLIESSENDEN Funktion
        /// darf aus einer verschachtelten Lambda heraus nicht per `break`
        /// erreichbar sein (andere Aufruf-/Scope-Ebene zur Laufzeit).</summary>
        private int _loopDepth;
        private int _tryDepth;
        private int _unsafeDepth;
        private ClassDecl? _currentClass;
        private bool _currentClassHasBase;

        /// <summary>Namen der generischen Typ-Parameter, die an der aktuellen
        /// Stelle sichtbar sind (Klassen-Typ-Parameter der umschließenden
        /// Klasse UNION Typ-Parameter der aktuell resolvten Methode, falls
        /// diese selbst generisch ist) - als Referenzzähler statt reinem
        /// HashSet, damit ein Methoden-Typ-Parameter mit ZUFÄLLIG demselben
        /// Namen wie ein Klassen-Typ-Parameter beim Verlassen der Methode
        /// nicht versehentlich auch den äußeren Namen entfernt (siehe
        /// AddTypeParamNames/RemoveTypeParamNames). ValidateTypeName
        /// akzeptiert diese Namen wie einen bekannten Typ (siehe dort),
        /// obwohl sie keine echte Klasse sind - eine echte Typ-Substitution
        /// findet NICHT statt (siehe SPEC "Generische Klassen"), `T` bleibt
        /// zur Laufzeit einfach unspezifisch.</summary>
        private readonly Dictionary<string, int> _currentTypeParamNames = new();

        private void AddTypeParamNames(IEnumerable<string> names)
        {
            foreach (var n in names)
                _currentTypeParamNames[n] = _currentTypeParamNames.GetValueOrDefault(n) + 1;
        }

        private void RemoveTypeParamNames(IEnumerable<string> names)
        {
            foreach (var n in names)
            {
                int count = _currentTypeParamNames[n] - 1;
                if (count <= 0) _currentTypeParamNames.Remove(n);
                else _currentTypeParamNames[n] = count;
            }
        }
        private bool _inConstructor;

        private Resolver(IEnumerable<string>? nativeNames, IEnumerable<string>? tryableNativeNames)
        {
            _current = _globalScope;
            _nativeNames = nativeNames != null ? new HashSet<string>(nativeNames) : new HashSet<string>();
            _tryableNativeNames = tryableNativeNames != null ? new HashSet<string>(tryableNativeNames) : new HashSet<string>();
        }

        public static ResolveResult Resolve(
            IReadOnlyList<Stmt> program, IEnumerable<string>? nativeNames = null, IEnumerable<string>? tryableNativeNames = null,
            IReadOnlyList<string>? activeUsings = null)
        {
            var resolver = new Resolver(nativeNames, tryableNativeNames);
            resolver._topLevelUsings = activeUsings ?? Array.Empty<string>();
            resolver.CollectClasses(program);
            resolver.BuildNamespaceIndex();
            resolver.CollectExterns(program);
            resolver.CollectEnums(program);
            resolver._noShadowGlobals = program.Any(s => s is NoShadowDirective);
            foreach (var stmt in program)
                resolver.ResolveStmt(stmt);

            return new ResolveResult
            {
                References = resolver._refs,
                Classes = resolver._classes,
                GlobalSlotCount = resolver._globalScope.Slots.Count,
                Externs = resolver._externs,
                NoShadowGlobals = resolver._noShadowGlobals,
            };
        }

        // -----------------------------------------------------------
        // extern-Deklarationen vorab einsammeln (erlaubt Aufrufe vor der
        // Deklaration im Quelltext, wie bei Klassen).
        // -----------------------------------------------------------
        private void CollectExterns(IReadOnlyList<Stmt> statements)
        {
            foreach (var stmt in statements)
            {
                if (stmt is not ExternDecl ed) continue;
                // Eine gleichnamige registrierte native Funktion ist kein Konflikt,
                // sondern der Normalfall: 'extern' deklariert die Signatur im
                // Skript, die native Registry liefert die Implementierung dazu.
                if (_externs.ContainsKey(ed.Name))
                    throw new ResolverException($"'{ed.Name}' ist bereits als extern deklariert", ed.Line);
                _externs[ed.Name] = ed;
            }
        }

        /// <summary>Sammelt alle `enum`-Deklarationen vorab (erlaubt Vorwärts-
        /// referenzen wie bei Klassen/externs) und berechnet dabei direkt die
        /// tatsächlichen Int-Werte jedes Mitglieds: ein explizit angegebener
        /// Wert MUSS ein Int-Literal sein (echte Compile-Zeit-Konstanten-
        /// auswertung beliebiger Ausdrücke gibt es in dieser Sprache nicht),
        /// sonst Auto-Increment vom Vorgänger + 1 (0 beim ersten Mitglied).</summary>
        private void CollectEnums(IReadOnlyList<Stmt> statements)
        {
            foreach (var stmt in statements)
            {
                if (stmt is not EnumDecl ed) continue;
                if (_enums.ContainsKey(ed.Name))
                    throw new ResolverException($"'{ed.Name}' ist bereits als enum deklariert", ed.Line);
                if (IsKnownClassName(ed.Name))
                    throw new ResolverException($"'{ed.Name}' ist bereits als Klasse deklariert", ed.Line);

                var members = new Dictionary<string, long>();
                long next = 0;
                foreach (var m in ed.Members)
                {
                    if (members.ContainsKey(m.Name))
                        throw new ResolverException($"Enum-Mitglied '{ed.Name}.{m.Name}' ist bereits deklariert", ed.Line);

                    long value;
                    if (m.ValueExpr != null)
                    {
                        if (m.ValueExpr is not LiteralExpr { Value.Kind: ValueKind.Int } lit)
                            throw new ResolverException(
                                $"Enum-Mitglied '{ed.Name}.{m.Name}': Wert muss ein Int-Literal sein " +
                                "(beliebige Ausdrücke werden hier nicht ausgewertet).", ed.Line);
                        value = lit.Value.AsInt();
                    }
                    else
                    {
                        value = next;
                    }

                    members[m.Name] = value;
                    next = value + 1;
                }

                _enums[ed.Name] = members;
            }
        }

        // -----------------------------------------------------------
        // Klassen & Interfaces vorab einsammeln (erlaubt Vorwärtsreferenzen und
        // dass 'new Foo()' funktioniert, auch wenn 'Foo' erst später im
        // Quelltext deklariert wird). Da der Parser nicht wissen kann, welcher
        // Name nach ':' die Basisklasse und welche Interfaces sind (das ist
        // erst hier, mit Kenntnis aller Klassen-/Interface-Namen, entscheidbar),
        // wird das hier aufgelöst: höchstens einer der Namen darf eine echte
        // Klasse (oder 'Exception') sein, alle anderen müssen bekannte
        // Interfaces sein.
        // -----------------------------------------------------------
        private void CollectClasses(IReadOnlyList<Stmt> statements)
        {
            foreach (var stmt in statements)
            {
                switch (stmt)
                {
                    case ClassDecl cd:
                        if (_classes.ContainsKey(cd.Name))
                            throw new ResolverException($"Klasse '{cd.Name}' ist bereits definiert", cd.Line);
                        _classes[cd.Name] = cd;
                        break;
                    case InterfaceDecl id:
                        if (_interfaces.ContainsKey(id.Name))
                            throw new ResolverException($"Interface '{id.Name}' ist bereits definiert", id.Line);
                        _interfaces[id.Name] = id;
                        break;
                }
            }

            foreach (var cd in _classes.Values)
            {
                string? baseName = null;
                foreach (var n in cd.BaseNames)
                {
                    bool isClass = n == "Exception" || _classes.ContainsKey(n);
                    if (isClass)
                    {
                        if (baseName != null)
                            throw new ResolverException(
                                $"Klasse '{cd.Name}' kann nicht mehrere Basisklassen haben ('{baseName}' und '{n}')", cd.Line);
                        baseName = n;
                    }
                    else if (!_interfaces.ContainsKey(n))
                    {
                        throw new ResolverException(
                            $"'{n}' bei Klasse '{cd.Name}' ist weder eine bekannte Klasse noch ein bekanntes Interface", cd.Line);
                    }
                }
            }

            foreach (var cd in _classes.Values)
                foreach (var n in cd.BaseNames)
                    if (_interfaces.TryGetValue(n, out var iface))
                        ValidateImplementsInterface(cd, iface);
        }

        private string? GetBaseClassName(ClassDecl cd)
        {
            foreach (var n in cd.BaseNames)
                if (n == "Exception" || _classes.ContainsKey(n))
                    return n;
            return null;
        }

        /// <summary>Prüft, ob `cd` (inkl. geerbter Methoden über die
        /// Basisklassen-Kette) alle Methoden von `iface` per Name+Arität
        /// bereitstellt. Reine strukturelle Prüfung, keine Rückgabetyp-
        /// Kontrolle - die Sprache ist dynamisch typisiert.</summary>
        private void ValidateImplementsInterface(ClassDecl cd, InterfaceDecl iface)
        {
            foreach (var m in iface.Methods)
            {
                if (!ClassHasMethod(cd, m.Name, m.Params.Count))
                    throw new ResolverException(
                        $"Klasse '{cd.Name}' implementiert Interface '{iface.Name}' nicht vollständig " +
                        $"(fehlende Methode '{m.Name}' mit {m.Params.Count} Parameter(n))", cd.Line);
            }
        }

        private bool ClassHasMethod(ClassDecl cd, string name, int arity)
        {
            foreach (var member in cd.Members)
                if (member is MethodDecl md && md.Name == name && md.Params.Count == arity)
                    return true;

            var baseName = GetBaseClassName(cd);
            if (baseName != null && _classes.TryGetValue(baseName, out var baseCd))
                return ClassHasMethod(baseCd, name, arity);
            return false;
        }

        private bool IsKnownClassName(string name) => name == "Exception" || _classes.ContainsKey(name);

        /// <summary>Prüft bei `new Name&lt;Arg1,...&gt;(...)` (siehe Ast.NewExpr.
        /// TypeArgs), ob die gegebenen Typ-Argumente zu den Typ-Parametern der
        /// Zielklasse passen (Anzahl) und deren 'where'-Constraints erfüllen
        /// (siehe Ast.TypeParam-Doku: ',' zwischen Gruppen = ODER, ':'
        /// innerhalb einer Gruppe = UND). Rein statische Prüfung, da
        /// Typ-Argumente NAMEN sind (Klassen/Interfaces/primitive Typen ODER,
        /// für eine 'is in'-Bedingung, Einheiten-Namen), keine Laufzeit-Werte
        /// - deshalb komplett hier im Resolver, ohne jede VM-Unterstützung.</summary>
        private void CheckTypeArgs(ClassDecl targetClass, NewExpr ne)
        {
            var typeParams = targetClass.TypeParams ?? Array.Empty<TypeParam>();

            if (typeParams.Count == 0)
            {
                if (ne.TypeArgs != null && ne.TypeArgs.Count > 0)
                    throw new ResolverException(
                        $"Klasse '{targetClass.Name}' ist nicht generisch, akzeptiert also keine " +
                        "Typ-Argumente in spitzen Klammern", ne.Line);
                return;
            }

            var typeArgs = ne.TypeArgs ?? Array.Empty<string>();
            if (typeArgs.Count != typeParams.Count)
                throw new ResolverException(
                    $"Klasse '{targetClass.Name}' ist generisch mit {typeParams.Count} Typ-Parameter(n) - " +
                    $"'new {targetClass.Name}<...>' braucht explizite Typ-Argumente dafür " +
                    $"(erhalten: {typeArgs.Count})", ne.Line);

            for (int i = 0; i < typeParams.Count; i++)
            {
                var tp = typeParams[i];
                string arg = typeArgs[i];
                if (tp.ConstraintGroups.Count == 0) continue; // uneingeschränkt ('<T>' ohne 'where')

                bool satisfied = tp.ConstraintGroups.Any(
                    group => group.Constraints.All(c => SatisfiesConstraint(arg, c)));
                if (!satisfied)
                    throw new ResolverException(
                        $"Typ-Argument '{arg}' für Typ-Parameter '{tp.Name}' von '{targetClass.Name}' erfüllt " +
                        "keine der 'where'-Bedingungen", ne.Line);
            }
        }

        private bool SatisfiesConstraint(string argName, TypeConstraint c) => c.Kind switch
        {
            TypeConstraintKind.IsOf => TypeNameSatisfiesIsOf(argName, c.Name),
            // 'is in': argName als Einheitenname interpretiert, dimensional
            // kompatibel mit c.Name (Unit.Parse wirft nie - ein unbekanntes
            // Symbol wird zu einer atomaren, nur zu sich selbst kompatiblen
            // Einheit, siehe Unit.Parse-Doku - das Ergebnis ist also einfach
            // "nicht erfüllt", kein Fehler).
            _ => Unit.Parse(argName).IsCompatibleWith(Unit.Parse(c.Name)),
        };

        /// <summary>Erfüllt der Typname `argName` ein 'is of `targetName`' -
        /// exakter Namens-Treffer, ODER (falls argName eine bekannte Klasse
        /// ist) `targetName` kommt irgendwo in dessen Basisklassen-/
        /// Interface-Kette vor. Rein NAMENS-basiert (keine Instanzen, keine
        /// Werte), analog zu ClassHasMethod.</summary>
        private bool TypeNameSatisfiesIsOf(string argName, string targetName)
        {
            if (argName == targetName) return true;
            if (!_classes.TryGetValue(argName, out var cd)) return false;
            foreach (var n in cd.BaseNames)
                if (TypeNameSatisfiesIsOf(n, targetName))
                    return true;
            return false;
        }

        private void ValidateTypeName(string name, int line)
        {
            if (PrimitiveTypeNames.Contains(name)) return;
            if (_currentTypeParamNames.ContainsKey(name)) return;
            if (!IsKnownClassName(ResolveNamespaceName(name)))
                throw new ResolverException($"Unbekannter Typ '{name}'", line);
        }

        /// <summary>Validiert einen vollständigen TypeRef: Basisname wie
        /// ValidateTypeName, plus - falls vorhanden - dass eine Bitbreite nur bei
        /// int/float steht und einer der erlaubten Werte (8/16/32/64) ist.
        /// Pointer-Tiefe ist immer gültig.</summary>
        private void ValidateTypeRef(TypeRef type, int line)
        {
            ValidateTypeName(type.BaseName, line);
            if (type.BitWidth == null) return;

            if (type.BaseName != "int" && type.BaseName != "float")
                throw new ResolverException(
                    $"Bitbreite ist nur für 'int'/'float' gültig, nicht für '{type.BaseName}'", line);
            if (type.BitWidth is not (8 or 16 or 32 or 64))
                throw new ResolverException(
                    $"Ungültige Bitbreite {type.BitWidth} (erlaubt: 8/16/32/64)", line);
        }

        private void ResolveArrayRanks(IReadOnlyList<Expr?> ranks)
        {
            foreach (var rank in ranks)
                if (rank != null) ResolveExpr(rank);
        }

        // -----------------------------------------------------------
        // Scope-Verwaltung
        // -----------------------------------------------------------
        private sealed class ResolverScope
        {
            public readonly ResolverScope? Parent;
            public readonly bool IsGlobal;
            public readonly Dictionary<string, int> Slots = new();
            public readonly HashSet<string> ReadonlySlots = new();

            public ResolverScope(ResolverScope? parent, bool isGlobal = false)
            {
                Parent = parent;
                IsGlobal = isGlobal;
            }
        }

        private void PushScope() => _current = new ResolverScope(_current);
        private void PopScope() => _current = _current.Parent!;

        private void Define(string name, int line, bool isReadonly = false)
        {
            if (_current.Slots.ContainsKey(name))
                throw new ResolverException($"'{name}' ist in diesem Scope bereits deklariert", line);
            _current.Slots[name] = _current.Slots.Count;
            if (isReadonly) _current.ReadonlySlots.Add(name);
        }

        private ResolvedRef ResolveIdentifierRef(string name, int line)
        {
            int depth = 0;
            var scope = _current;
            while (scope != null)
            {
                if (scope.Slots.TryGetValue(name, out int slot))
                    return scope.IsGlobal
                        ? new ResolvedRef.Global(slot)
                        : new ResolvedRef.Local(depth, slot);
                depth++;
                scope = scope.Parent;
            }

            if (_nativeNames.Contains(name))
                return new ResolvedRef.Native(name);
            if (_externs.ContainsKey(name))
                return new ResolvedRef.Extern(name);
            if (_tryableNativeNames.Contains(name))
                throw new ResolverException(
                    $"'{name}' ist als 'tryable' registriert - nur mit 'try {name}(...)' aufrufbar, " +
                    "nicht als direkter Aufruf.", line);

            throw new ResolverException($"Unbekannter Bezeichner '{name}'", line);
        }

        /// <summary>Läuft dieselbe Scope-Kette wie ResolveIdentifierRef ab, nur um
        /// zu prüfen, ob eine Variable per `readonly` deklariert wurde - für
        /// den Zuweisungs-Check in ResolveAssignTarget (der die Variable ja
        /// bereits per ResolveIdentifierRef erfolgreich aufgelöst hat, hier
        /// also immer fündig wird).</summary>
        private bool IsReadonlyVariable(string name)
        {
            var scope = _current;
            while (scope != null)
            {
                if (scope.Slots.ContainsKey(name))
                    return scope.ReadonlySlots.Contains(name);
                scope = scope.Parent;
            }
            return false;
        }

        // -----------------------------------------------------------
        // Statements
        // -----------------------------------------------------------
        private void ResolveStmt(Stmt stmt)
        {
            switch (stmt)
            {
                case Stmt.BlockStmt block:
                    ResolveBlockNewScope(block);
                    break;

                case ExprStmt es:
                    ResolveExpr(es.Expression);
                    break;

                case NoOpStmt:
                    break;

                case NoShadowDirective:
                    // Bereits im Vorab-Pass (CollectNoShadowDirective)
                    // eingesammelt - hier nichts mehr zu tun.
                    break;

                case VarDeclStmt vd:
                    if (vd.Initializer != null) ResolveExpr(vd.Initializer);
                    if (vd.Type != null) ValidateTypeRef(vd.Type, vd.Line);
                    ResolveArrayRanks(vd.ArrayRanks);
                    if (vd.IsReadonly && vd.Initializer == null &&
                        !(vd.ArrayRanks.Count > 0 && vd.ArrayRanks[0] != null))
                        throw new ResolverException(
                            $"'readonly {vd.Name}' braucht einen Initializer (oder eine Array-Größe)", vd.Line);
                    // 'var arr[4] = [1,2,3,4]' (explizite Größe UND ein
                    // Array-Literal als Initializer) - nur eine BESTE-EFFORT-
                    // Prüfung, wenn die Größe selbst ein Ganzzahl-LITERAL ist
                    // (der häufige Fall): stimmt sie nicht mit der Anzahl der
                    // Literal-Elemente überein, ist das ein Compile-Fehler
                    // statt eines stillschweigend anders großen Arrays (die
                    // deklarierte Größe würde sonst OHNE jede Meldung vom
                    // Initializer überschrieben, siehe Compiler.CompileStmt).
                    // Eine DYNAMISCHE Größe (Variable/Ausdruck) wird hier
                    // NICHT geprüft - dafür bräuchte es eine Laufzeit-Prüfung,
                    // die diese Ausbaustufe bewusst nicht baut.
                    if (vd.Initializer is ArrayLiteralExpr arrLit
                        && vd.ArrayRanks.Count > 0 && vd.ArrayRanks[0] is LiteralExpr sizeLit
                        && sizeLit.Value.Kind == ValueKind.Int
                        && sizeLit.Value.AsInt() != arrLit.Elements.Count)
                        throw new ResolverException(
                            $"'{vd.Name}[{sizeLit.Value.AsInt()}]' erwartet {sizeLit.Value.AsInt()} Elemente, " +
                            $"der Array-Literal-Initializer hat aber {arrLit.Elements.Count}", vd.Line);
                    Define(vd.Name, vd.Line, vd.IsReadonly);
                    break;

                case IfStmt ifs:
                    ResolveExpr(ifs.Condition);
                    ResolveStmtAsScope(ifs.Then);
                    if (ifs.Else != null) ResolveStmtAsScope(ifs.Else);
                    break;

                case WhileStmt ws:
                    ResolveExpr(ws.Condition);
                    _loopDepth++;
                    ResolveStmtAsScope(ws.Body);
                    _loopDepth--;
                    break;

                case ForStmt fs:
                    ResolveFor(fs);
                    break;

                case ForeachStmt fe:
                    ResolveForeach(fe);
                    break;

                case ReturnStmt rs:
                    if (_functionDepth == 0)
                        throw new ResolverException("'return' außerhalb einer Funktion/Methode", rs.Line);
                    if (rs.Value != null) ResolveExpr(rs.Value);
                    break;

                case ThrowStmt ts:
                    ResolveExpr(ts.Value);
                    break;

                case TryStmt trys:
                    ResolveTry(trys);
                    break;

                case BreakStmt bs:
                    if (_loopDepth == 0)
                        throw new ResolverException("'break' außerhalb einer Schleife ('while'/'for'/'foreach')", bs.Line);
                    if (_tryDepth > 0)
                        throw new ResolverException(
                            "'break' kann nicht aus einem 'try'/'catch'/'finally' heraus verwendet werden " +
                            "(Einschränkung dieser Ausbaustufe - siehe BYTECODE.md)", bs.Line);
                    break;

                case ContinueStmt cs:
                    if (_loopDepth == 0)
                        throw new ResolverException("'continue' außerhalb einer Schleife ('while'/'for'/'foreach')", cs.Line);
                    if (_tryDepth > 0)
                        throw new ResolverException(
                            "'continue' kann nicht aus einem 'try'/'catch'/'finally' heraus verwendet werden " +
                            "(Einschränkung dieser Ausbaustufe - siehe BYTECODE.md)", cs.Line);
                    break;

                case FireStmt fireStmt:
                    ResolveFireStmt(fireStmt);
                    break;

                case LeaveStmt:
                    // Bewusst keine Einschränkung auf "nur innerhalb eines
                    // fire-Blocks" (siehe Ast.LeaveStmt-Doku) - nichts zu
                    // prüfen.
                    break;

                case TerminateStmt terminateStmt:
                    if (terminateStmt.Value != null) ResolveExpr(terminateStmt.Value);
                    break;

                case CatchThreadsDecl threadsDecl:
                    if (threadsDecl.TypeName != null && !IsKnownClassName(ResolveNamespaceName(threadsDecl.TypeName)))
                        throw new ResolverException($"Unbekannter Exception-Typ '{threadsDecl.TypeName}'", threadsDecl.Line);
                    ResolveGlobalHandlerBody(threadsDecl.VarName, threadsDecl.Body);
                    break;

                case CatchTerminateDecl terminateDecl:
                    ResolveGlobalHandlerBody(terminateDecl.VarName, terminateDecl.Body);
                    break;

                case ProcessStmt processStmt:
                    ResolveExpr(processStmt.Target);
                    break;

                case ClassDecl cd:
                    ResolveClass(cd);
                    break;

                case InterfaceDecl:
                    // Bereits im Vorab-Pass (CollectClasses) validiert - hier nichts zu tun.
                    break;

                case EnumDecl:
                    // Bereits im Vorab-Pass (CollectEnums) validiert und mit
                    // Werten befüllt - hier nichts zu tun.
                    break;

                case ClassExtensionDecl cx:
                    // Sollte NIE hier ankommen - Parser.MergeClassExtensions
                    // löst das schon vor dem Resolven vollständig auf (siehe
                    // Ast.ClassExtensionDecl-Doku). Nur als Sicherheitsnetz,
                    // falls das Programm auf einem anderen Weg als über
                    // Parser.Parse()/ParseWithPrelude() erzeugt wurde.
                    throw new ResolverException(
                        $"Interner Fehler: 'class extends {cx.TargetName}' wurde nicht zusammengeführt " +
                        "(Programm muss über Parser.Parse()/ParseWithPrelude() erzeugt werden).", cx.Line);

                case ExternDecl ed:
                    if (ed.ReturnType != null) ValidateTypeRef(ed.ReturnType, ed.Line);
                    foreach (var p in ed.Params)
                    {
                        if (p.Type != null) ValidateTypeRef(p.Type, ed.Line);
                        ResolveArrayRanks(p.ArrayRanks);
                    }
                    break;

                case UnsafeStmt us:
                    _unsafeDepth++;
                    ResolveBlockNewScope(us.Body);
                    _unsafeDepth--;
                    break;

                default:
                    throw new ResolverException(
                        $"Unerwartetes Statement {stmt.GetType().Name} an dieser Stelle", stmt.Line);
            }
        }

        /// <summary>Löst ein Statement so auf, dass es einen eigenen Scope bekommt -
        /// entweder direkt (wenn es schon ein Block ist) oder über einen
        /// Wegwerf-Scope (für einzeilige if/while/for-Bodies ohne '{}').</summary>
        private void ResolveStmtAsScope(Stmt body)
        {
            if (body is Stmt.BlockStmt block)
            {
                ResolveBlockNewScope(block);
            }
            else
            {
                PushScope();
                ResolveStmt(body);
                PopScope();
            }
        }

        private void ResolveBlockNewScope(Stmt.BlockStmt block)
        {
            PushScope();
            foreach (var s in block.Statements) ResolveStmt(s);
            PopScope();
        }

        private void ResolveFor(ForStmt fs)
        {
            PushScope(); // umschließt Init/Condition/Increment/Body gemeinsam
            if (fs.Init != null) ResolveStmt(fs.Init);
            if (fs.Condition != null) ResolveExpr(fs.Condition);
            if (fs.Increment != null) ResolveExpr(fs.Increment);
            _loopDepth++;
            ResolveStmtAsScope(fs.Body);
            _loopDepth--;
            PopScope();
        }

        private void ResolveForeach(ForeachStmt fe)
        {
            ResolveExpr(fe.Iterable); // im umschließenden Scope, nicht im Loop-Scope
            PushScope();
            Define(fe.VarName, fe.Line);
            _loopDepth++;
            ResolveStmtAsScope(fe.Body);
            _loopDepth--;
            PopScope();
        }

        /// <summary>`break`/`continue` dürfen (siehe ResolveStmt) nicht aus
        /// einem `try`/`catch`/`finally` heraus verwendet werden - deshalb
        /// wird `_tryDepth` hier für ALLE drei Teile hochgezählt (nicht nur
        /// den Try-Block selbst). Bewusste Einschränkung: die VM verwaltet
        /// den registrierten Exception-Handler UND die try-eigenen Scopes
        /// über eigene Opcodes (RegisterHandler/UnregisterHandler) - ein
        /// `break`/`continue`-Sprung, der das sauber mit abräumt, wäre ein
        /// riskanteres, deutlich größeres Stück Arbeit, das hier bewusst
        /// nicht mit angegangen wird (siehe BYTECODE.md).</summary>
        private void ResolveTry(TryStmt t)
        {
            _tryDepth++;
            ResolveBlockNewScope(t.TryBlock);

            foreach (var c in t.Catches)
            {
                if (c.TypeName != null && !IsKnownClassName(ResolveNamespaceName(c.TypeName)))
                    throw new ResolverException($"Unbekannter Exception-Typ '{c.TypeName}'", c.Line);

                PushScope();
                Define(c.VarName, c.Line);
                foreach (var s in c.Body.Statements) ResolveStmt(s);
                PopScope();
            }

            if (t.Finally != null) ResolveBlockNewScope(t.Finally);
            _tryDepth--;
        }

        // -----------------------------------------------------------
        // Klassen
        // -----------------------------------------------------------
        private void ResolveClass(ClassDecl cd)
        {
            var savedClass = _currentClass;
            var savedHasBase = _currentClassHasBase;
            _currentClass = cd;
            _currentClassHasBase = GetBaseClassName(cd) != null;

            var classTypeParamNames = cd.TypeParams?.Select(tp => tp.Name).ToList() ?? new List<string>();
            AddTypeParamNames(classTypeParamNames);

            // Pro Klasse: erlaubt mehrere Methoden desselben Namens
            // (Überladung), aber nur mit UNTERSCHIEDLICHER Parameteranzahl -
            // das ist die einzige zur Aufrufzeit generell unterscheidbare
            // Signatur in einer dynamisch typisierten Sprache (siehe
            // RuntimeClass.FindMethod-Doku). Konstruktoren ebenso, aber in
            // einer EIGENEN Zählung (der Name spielt dort ja keine Rolle -
            // es gibt nur "den" Konstruktor einer Klasse, mehrere
            // Überladungen unterscheiden sich rein über die Arity).
            var seenMethodSignatures = new HashSet<(string Name, int Arity)>();
            var seenConstructorArities = new HashSet<int>();

            foreach (var member in cd.Members)
            {
                switch (member)
                {
                    case FieldDecl fd:
                        if (fd.Type != null) ValidateTypeRef(fd.Type, fd.Line);
                        ResolveArrayRanks(fd.ArrayRanks);
                        ResolveFieldInitializer(fd);
                        break;

                    case ConstructorDecl ctor:
                        if (!seenConstructorArities.Add(ctor.Params.Count))
                            throw new ResolverException(
                                $"Konstruktor mit {ctor.Params.Count} Parameter(n) ist in dieser Klasse " +
                                "bereits definiert (eine Überladung braucht eine andere Parameteranzahl).", ctor.Line);
                        ResolveFunctionLike(ctor.Params, ctor.Body, ctor.BaseArgs, isConstructor: true);
                        break;

                    case DestructorDecl dtor:
                        ResolveFunctionLike(Array.Empty<LambdaParam>(), dtor.Body, baseArgs: null, isConstructor: false);
                        break;

                    case MethodDecl md:
                        var methodTypeParamNames = md.TypeParams?.Select(tp => tp.Name).ToList() ?? new List<string>();
                        AddTypeParamNames(methodTypeParamNames);
                        try
                        {
                            if (md.ReturnType != null)
                                ValidateTypeRef(md.ReturnType, md.Line);
                            if (!seenMethodSignatures.Add((md.Name, md.Params.Count)))
                                throw new ResolverException(
                                    $"Methode '{md.Name}' mit {md.Params.Count} Parameter(n) ist in dieser Klasse " +
                                    "bereits definiert (eine Überladung braucht eine andere Parameteranzahl).", md.Line);
                            ResolveFunctionLike(md.Params, md.Body, baseArgs: null, isConstructor: false);
                        }
                        finally
                        {
                            RemoveTypeParamNames(methodTypeParamNames);
                        }
                        break;

                    case PropertyDecl pd:
                        if (pd.Type != null) ValidateTypeRef(pd.Type, pd.Line);
                        // Getter: wie eine parameterlose Methode. Setter: wie
                        // eine Methode mit genau einem Parameter 'value' vom
                        // Property-Typ (implizit, wie C#s Setter-Parameter) -
                        // ganz normale Parameter-Auflösung, keine
                        // Sonderbehandlung nötig.
                        if (pd.Getter != null)
                            ResolveFunctionLike(Array.Empty<LambdaParam>(), pd.Getter, baseArgs: null, isConstructor: false);
                        if (pd.Setter != null)
                        {
                            var setterParams = new[] { new LambdaParam("value", pd.Type, Array.Empty<Expr?>()) };
                            ResolveFunctionLike(setterParams, pd.Setter, baseArgs: null, isConstructor: false);
                        }
                        break;
                }
            }

            RemoveTypeParamNames(classTypeParamNames);
            _currentClass = savedClass;
            _currentClassHasBase = savedHasBase;
        }

        /// <summary>Feld-Initialisierer sehen (wie Lambdas) nur ihren eigenen Scope
        /// + global - plus implizit 'this', da sie pro Instanz im Konstruktor-
        /// Kontext ausgewertet werden, aber nicht die Parameter irgendeines
        /// bestimmten Konstruktors kennen.</summary>
        private void ResolveFieldInitializer(FieldDecl fd)
        {
            if (fd.Initializer == null) return;
            var saved = _current;
            _current = new ResolverScope(_globalScope);
            ResolveExpr(fd.Initializer);
            _current = saved;
        }

        /// <summary>Optionale Parameter (mit Standardwert) müssen am Ende der
        /// Parameterliste ZUSAMMENHÄNGEN - kein Pflichtparameter nach einem
        /// optionalen (sonst wäre bei einem Aufruf mit weniger Argumenten
        /// nicht eindeutig, welcher Parameter "fehlt"). Dieselbe Regel wie in
        /// den meisten Sprachen mit optionalen Parametern.</summary>
        private static void ValidateOptionalParamsAreTrailing(IReadOnlyList<LambdaParam> parms, int line)
        {
            bool seenOptional = false;
            foreach (var p in parms)
            {
                if (p.DefaultValue != null) { seenOptional = true; continue; }
                if (seenOptional)
                    throw new ResolverException(
                        $"Parameter '{p.Name}' ohne Standardwert darf nicht nach einem optionalen Parameter " +
                        "stehen (optionale Parameter müssen am Ende zusammenhängen).", line);
            }
        }

        /// <summary>Standardwert-Ausdrücke sehen wie Feld-Initialisierer (siehe
        /// ResolveFieldInitializer) nur ihren eigenen Scope + global + `this`
        /// - NICHT die anderen Parameter derselben Funktion, da sie
        /// unabhängig von diesen ausgewertet werden (siehe VM.
        /// FillDefaultArgs - eine eigene, isolierte Auswertung pro fehlendem
        /// Parameter, nicht Teil des normalen Funktions-Scopes).</summary>
        private void ResolveParamDefaults(IReadOnlyList<LambdaParam> parms)
        {
            var saved = _current;
            _current = new ResolverScope(_globalScope);
            foreach (var p in parms)
                if (p.DefaultValue != null)
                    ResolveExpr(p.DefaultValue);
            _current = saved;
        }

        private void ResolveFunctionLike(
            IReadOnlyList<LambdaParam> parms, Stmt.BlockStmt body, IReadOnlyList<Expr>? baseArgs, bool isConstructor)
        {
            ValidateOptionalParamsAreTrailing(parms, body.Line);
            ResolveParamDefaults(parms);

            PushScope();
            foreach (var p in parms)
            {
                if (p.Type != null) ValidateTypeRef(p.Type, body.Line);
                ResolveArrayRanks(p.ArrayRanks);
                Define(p.Name, body.Line);
            }

            if (baseArgs != null)
            {
                if (!_currentClassHasBase)
                    throw new ResolverException(
                        "'base(...)' nur in einer Klasse mit Basisklasse gültig", body.Line);
                foreach (var a in baseArgs) ResolveExpr(a);
            }

            // WICHTIG: NICHT von 'baseArgs != null' ableiten - das heißt nur
            // "hat ein EXPLIZITES 'base(...)'", nicht "ist ein Konstruktor".
            // Eine Klasse ohne Basisklasse hat nie baseArgs, ihr Konstruktor
            // braucht das Flag aber trotzdem.
            bool savedInConstructor = _inConstructor;
            _inConstructor = isConstructor;

            int savedLoopDepth = _loopDepth;
            int savedTryDepth = _tryDepth;
            _loopDepth = 0;
            _tryDepth = 0;

            _functionDepth++;
            foreach (var s in body.Statements) ResolveStmt(s);
            _functionDepth--;

            _loopDepth = savedLoopDepth;
            _tryDepth = savedTryDepth;

            _inConstructor = savedInConstructor;

            PopScope();
        }

        // -----------------------------------------------------------
        // Ausdrücke
        // -----------------------------------------------------------
        private void ResolveExpr(Expr expr)
        {
            switch (expr)
            {
                case LiteralExpr:
                    break;

                case IdentifierExpr id:
                    _refs[id] = ResolveIdentifierRef(id.Name, id.Line);
                    break;

                case ThisExpr:
                    break; // Laufzeit entscheidet, ob/was 'this' aktuell gebunden ist

                case BaseExpr be:
                    if (_currentClass == null || !_currentClassHasBase)
                        throw new ResolverException(
                            "'base' nur innerhalb einer Klasse mit Basisklasse gültig", be.Line);
                    break;

                case UnaryExpr u:
                    if ((u.Op == UnaryOp.Dereference || u.Op == UnaryOp.AddressOf) && _unsafeDepth == 0)
                        throw new ResolverException(
                            $"'{(u.Op == UnaryOp.Dereference ? "*" : "&")}' ist nur innerhalb eines 'unsafe'-Blocks gültig", u.Line);
                    ResolveExpr(u.Operand);
                    break;

                case BinaryExpr b:
                    ResolveExpr(b.Left);
                    ResolveExpr(b.Right);
                    break;

                case UnitCoerceExpr uc:
                    ResolveExpr(uc.Operand);
                    break;

                case TypeCoerceExpr tc:
                    ResolveExpr(tc.Operand);
                    break;

                case IsInExpr iin:
                    ResolveExpr(iin.Operand);
                    break;

                case IsOfExpr iof:
                    ResolveExpr(iof.Operand);
                    ValidateTypeName(iof.TypeName, iof.Line);
                    break;

                case IsFromExpr ifr:
                    ResolveExpr(ifr.Operand);
                    ResolveExpr(ifr.OwnerExpr);
                    break;

                case CallExpr call:
                    ResolveExpr(call.Callee);
                    foreach (var a in call.Args) ResolveExpr(a);
                    break;

                case MemberExpr me:
                    // 'EnumName.Mitglied' - erkannt rein daran, dass der
                    // Zielname (als bloßer Bezeichner) ein bekannter enum-Name
                    // ist. Bewusste Design-Entscheidung: ein enum-Name "gewinnt"
                    // dabei immer gegen eine gleichnamige Variable im Scope
                    // (wie ein Klassenname auch nicht durch eine Variable
                    // verschattet werden kann) - dieselbe Namenskollision wäre
                    // ohnehin verwirrend und in der Praxis leicht vermeidbar.
                    if (me.Target is IdentifierExpr enumId && _enums.TryGetValue(enumId.Name, out var enumMembers))
                    {
                        if (!enumMembers.TryGetValue(me.Name, out long enumValue))
                            throw new ResolverException($"'{enumId.Name}' hat kein Mitglied '{me.Name}'", me.Line);
                        _refs[me] = new ResolvedRef.EnumMember(enumValue);
                        break;
                    }
                    ResolveExpr(me.Target); // .Name bleibt unresolved - dynamischer Feld-/Methodenzugriff
                    break;

                case IndexExpr ix:
                    ResolveExpr(ix.Target);
                    ResolveExpr(ix.Index);
                    break;

                case AssignExpr asg:
                    ResolveExpr(asg.Value);
                    ResolveAssignTarget(asg.Target);
                    break;

                case IncDecExpr incDec:
                    // Braucht sowohl Lese- als auch Schreibzugriff auf
                    // dasselbe Ziel - ResolveAssignTarget deckt beides ab
                    // (füllt für IdentifierExpr z.B. _refs genauso wie ein
                    // normales Lesen es täte, siehe dort), zusätzlich noch
                    // die readonly-/unsafe-Prüfungen, die für Zuweisungen
                    // ohnehin gelten und für '++'/'--' genauso gelten müssen.
                    ResolveAssignTarget(incDec.Target);
                    break;

                case NewExpr ne:
                    string resolvedNewClassName = ResolveNamespaceName(ne.ClassName);
                    if (!IsKnownClassName(resolvedNewClassName))
                        throw new ResolverException($"Unbekannte Klasse '{ne.ClassName}'", ne.Line);
                    if (_classes.TryGetValue(resolvedNewClassName, out var newTargetCd))
                        CheckTypeArgs(newTargetCd, ne);
                    else if (ne.TypeArgs != null && ne.TypeArgs.Count > 0)
                        throw new ResolverException(
                            $"'{ne.ClassName}' ist nicht generisch, akzeptiert also keine Typ-Argumente in spitzen Klammern",
                            ne.Line);
                    foreach (var a in ne.Args) ResolveExpr(a);
                    break;

                case NewArrayExpr na:
                    ValidateTypeRef(na.ElementType, na.Line);
                    if (na.SizeExprs.Count == 0 || na.SizeExprs[0] == null)
                        throw new ResolverException(
                            "'new Type[...]' braucht mindestens für die erste Dimension eine Größe " +
                            "(z.B. 'new int[3]' oder 'new int[3][]' - nicht 'new int[]').", na.Line);
                    ResolveArrayRanks(na.SizeExprs);
                    break;

                case NewBufferExpr nb:
                    ResolveExpr(nb.SizeExpr);
                    break;

                case ArrayLiteralExpr al:
                    foreach (var el in al.Elements) ResolveExpr(el);
                    break;

                case InterpolatedStringExpr ise:
                    foreach (var part in ise.Parts)
                        if (part is InterpolationExprPart ep) ResolveExpr(ep.Expression);
                    break;

                case ThrowExpr th:
                    ResolveExpr(th.Value);
                    break;

                case LambdaExpr lam:
                    ResolveLambda(lam);
                    break;

                case SyncExpr syncExpr:
                    ResolveExpr(syncExpr.Target);
                    break;

                case TryProcessExpr tryProcessExpr:
                    ResolveExpr(tryProcessExpr.Target);
                    break;

                case TryCallExpr tryCallExpr:
                    ResolveTryCallExpr(tryCallExpr);
                    break;

                default:
                    throw new ResolverException($"Unbekannter Ausdruckstyp {expr.GetType().Name}", expr.Line);
            }
        }

        /// <summary>`try Name(args)` (siehe Ast.TryCallExpr) - der innere
        /// Aufruf MUSS ein direkter Aufruf eines BEKANNTEN, als "tryable"
        /// registrierten Namens sein (siehe Bytecode.NativeRegistry.
        /// RegisterTryable) - kein Methodenaufruf, kein Lambda-Aufruf, kein
        /// gewöhnlicher/als 'extern' deklarierter nativer Name (die dürfen
        /// NICHT mit 'try' aufgerufen werden - nur registrierte "tryable"
        /// APIs). Der Callee selbst wird bewusst NICHT über ResolveExpr
        /// aufgelöst (das würde als normaler Bezeichner scheitern oder
        /// fälschlich einen ResolvedRef.Native/Extern setzen) - stattdessen
        /// hängt hier direkt eine eigene ResolvedRef.TryableNative am
        /// TryCallExpr-Knoten selbst, die der Compiler abfragt.</summary>
        private void ResolveTryCallExpr(TryCallExpr tc)
        {
            if (tc.Call is not CallExpr innerCall || innerCall.Callee is not IdentifierExpr calleeIdent)
                throw new ResolverException(
                    "'try' vor einem Aufruf erwartet einen direkten Aufruf einer registrierten Funktion " +
                    "(kein Methodenaufruf, kein Lambda-Aufruf)", tc.Line);

            if (!_tryableNativeNames.Contains(calleeIdent.Name))
                throw new ResolverException(
                    _nativeNames.Contains(calleeIdent.Name) || _externs.ContainsKey(calleeIdent.Name)
                        ? $"'{calleeIdent.Name}' ist keine 'tryable' registrierte Funktion - nur mit 'try' " +
                          "aufrufbare APIs dürfen so aufgerufen werden, normale native/extern-Funktionen nicht."
                        : $"'{calleeIdent.Name}' ist keine bekannte 'tryable' registrierte native Funktion.",
                    tc.Line);

            foreach (var a in innerCall.Args) ResolveExpr(a);
            _refs[tc] = new ResolvedRef.TryableNative(calleeIdent.Name);
        }

        private void ResolveAssignTarget(Expr target)
        {
            switch (target)
            {
                case IdentifierExpr id:
                    if (IsReadonlyVariable(id.Name))
                        throw new ResolverException(
                            $"'{id.Name}' ist 'readonly' und kann nach der Deklaration nicht mehr zugewiesen werden", id.Line);
                    _refs[id] = ResolveIdentifierRef(id.Name, id.Line);
                    break;
                case MemberExpr me:
                    // readonly-Felder dürfen NUR als 'this.feld = ...' innerhalb
                    // eines Konstruktors DER DEKLARIERENDEN Klasse zugewiesen
                    // werden - das ist rein statisch prüfbar (Ziel ist lexikalisch
                    // 'this', aktuelle Klasse ist bekannt). Für ein dynamisches
                    // Ziel ('obj.feld = ...', 'obj' beliebiger Ausdruck) kann der
                    // Resolver mangels statischem Typsystem NICHT wissen, welche
                    // Klasse gemeint ist - bewusste Grenze dieser Ausbaustufe,
                    // siehe FieldDecl-Doku.
                    if (me.Target is ThisExpr && _currentClass != null && IsReadonlyField(_currentClass, me.Name) && !_inConstructor)
                        throw new ResolverException(
                            $"'{_currentClass.Name}.{me.Name}' ist 'readonly' und kann nur innerhalb eines " +
                            "Konstruktors der deklarierenden Klasse zugewiesen werden", me.Line);
                    ResolveExpr(me.Target);
                    break;
                case IndexExpr ix:
                    ResolveExpr(ix.Target);
                    ResolveExpr(ix.Index);
                    break;
                case UnaryExpr { Op: UnaryOp.Dereference } deref:
                    if (_unsafeDepth == 0)
                        throw new ResolverException(
                            "'*' als Zuweisungsziel ist nur innerhalb eines 'unsafe'-Blocks gültig", deref.Line);
                    ResolveExpr(deref.Operand);
                    break;
                default:
                    throw new ResolverException("Ungültiges Zuweisungsziel", target.Line);
            }
        }

        /// <summary>Ist `fieldName` als `readonly` in `cd` (NUR diese Klasse
        /// selbst, keine Basisklassen-Kette - bewusste Grenze) deklariert?</summary>
        private static bool IsReadonlyField(ClassDecl cd, string fieldName) =>
            cd.Members.Any(m => m is FieldDecl { IsReadonly: true } fd && fd.Name == fieldName);

        /// <summary>Lambdas sehen nur ihren eigenen Scope + global (SPEC 4.2): der
        /// neue Scope wird bewusst direkt an den globalen Scope gehängt, nicht an
        /// den aktuell umschließenden - dadurch "funktioniert" die eingeschränkte
        /// Sichtbarkeit einfach durch die normale Tiefen-Zählung beim Auflösen,
        /// ganz ohne Sonderfall dort. 'on obj' wird dagegen VOR dem Scope-Wechsel
        /// aufgelöst, weil es im umschließenden Kontext ausgewertet wird (dort, wo
        /// die Lambda selbst definiert wird), nicht innerhalb ihres Bodys.</summary>
        /// <summary>`fire { ... }`/`fire taking X { ... }`/`fire with actorA { ... }`
        /// (siehe Ast.FireStmt-Doku): jede `TakingCaptures`-Quelle sowie
        /// `WithSource` (falls vorhanden) werden ganz normal im AUFRUFENDEN
        /// Scope aufgelöst (die jeweilige Variable muss dort bereits
        /// deklariert sein - oder, bei der `fire MethodA(...)`-Aufrufform,
        /// ein synthetisches `this`/ein Argumentausdruck sein). Der Body
        /// dagegen bekommt einen KOMPLETT ISOLIERTEN Scope (`ResolverScope(null,
        /// isGlobal: true)` - bewusst NICHT `_globalScope` wie bei Lambdas, siehe
        /// FireStmt-Doku: der
        /// Fire-Block läuft auf einer eigenen VM-Instanz mit eigenem,
        /// frischen globalen Scope). `return` ist
        /// innerhalb eines Fire-Blocks nicht sinnvoll (keine Rückgabewerte,
        /// SPEC) - `_functionDepth` wird deshalb für die Dauer der
        /// Body-Auflösung auf 0 zurückgesetzt, damit ein `return` darin wie
        /// "außerhalb einer Funktion" abgelehnt wird.
        ///
        /// WICHTIG: Reihenfolge der Slot-Vergabe hier ist die "Wahrheit", mit
        /// der Compiler.CompileFireStmt und Runtime.FireRuntime.FireVmTaking
        /// übereinstimmen MÜSSEN - ZUERST alle Hauptprogramm-Globals (als
        /// READONLY-Schatten, an DENSELBEN Slots wie im Hauptprogramm - siehe
        /// unten), DANN alle TakingCaptures (in Listenreihenfolge), dann
        /// with. Das ermöglicht den in docs/THREADING_DESIGN.md Abschnitt 8
        /// vorgesehenen Read-only-Snapshot: der Fire-Thread bekommt bei
        /// seinem Start eine EIGENE, isolierte Kopie ALLER Hauptprogramm-
        /// Globals (siehe VM.OpCode.Fire) - lesend sichtbar unter demselben
        /// Namen wie im Hauptprogramm, aber NICHT beschreibbar (eine
        /// Zuweisung würde ja nur die lokale Kopie ändern, nie das Original
        /// - das wäre stillschweigend falsch, deshalb hier hart abgelehnt
        /// statt zugelassen).</summary>
        private void ResolveFireStmt(FireStmt fs)
        {
            foreach (var capture in fs.TakingCaptures)
                ResolveExpr(capture.Source);
            if (fs.WithSource != null)
                ResolveExpr(fs.WithSource);

            var saved = _current;
            _current = new ResolverScope(null, isGlobal: true);

            // Schatten-Einträge für ALLE Hauptprogramm-Globals, an deren
            // ORIGINAL-Slots (0..GlobalSlotCount-1) - der Laufzeit-Snapshot
            // (siehe VM.OpCode.Fire) kopiert exakt diese Slots 1:1 in den
            // frischen globalen Scope des Fire-Threads, deshalb müssen die
            // Slot-NUMMERN hier unverändert übernommen werden, nicht neu
            // vergeben werden. Per '#noshadow' abschaltbar (siehe
            // Ast.NoShadowDirective-Doku) - dann verhält sich alles wie vor
            // Einführung des Snapshots: taking/with bekommen ihre Slots
            // wieder ab 0.
            if (!_noShadowGlobals)
                foreach (var (name, slot) in _globalScope.Slots)
                {
                    _current.Slots[name] = slot;
                    _current.ReadonlySlots.Add(name);
                }

            // taking/with - bekommen NEUE, EIGENE Slots ab hier (direkt
            // nach den Hauptprogramm-Globals, oder ab 0 bei aktivem
            // '#noshadow'). Kollidiert eine Erfassung NAMENTLICH mit einem
            // Hauptprogramm-Global, VERDRÄNGT sie dessen Schatten-Eintrag
            // (normale lexikalische Schattierung - die explizite, eigene
            // Erfassung ist im Fire-Block-Body dann gemeint, nicht das
            // gleichnamige Hauptprogramm-Global) und ist selbst ganz normal
            // beschreibbar wie bisher, NICHT readonly.
            int nextCaptureSlot = _noShadowGlobals ? 0 : _globalScope.Slots.Count;
            var capturesSeen = new HashSet<string>();
            foreach (var capture in fs.TakingCaptures)
            {
                if (!capturesSeen.Add(capture.VarName))
                    throw new ResolverException($"'{capture.VarName}' wurde in diesem 'fire' bereits erfasst", fs.Line);
                _current.Slots[capture.VarName] = nextCaptureSlot++;
                _current.ReadonlySlots.Remove(capture.VarName);
            }
            if (fs.WithVarName != null)
            {
                if (!capturesSeen.Add(fs.WithVarName))
                    throw new ResolverException($"'{fs.WithVarName}' wurde in diesem 'fire' bereits erfasst", fs.Line);
                _current.Slots[fs.WithVarName] = nextCaptureSlot++;
                _current.ReadonlySlots.Remove(fs.WithVarName);
            }

            int savedLoopDepth = _loopDepth;
            int savedTryDepth = _tryDepth;
            int savedFunctionDepth = _functionDepth;
            bool savedInConstructor = _inConstructor;
            _loopDepth = 0;
            _tryDepth = 0;
            _functionDepth = 0;
            _inConstructor = false;

            foreach (var s in fs.Body.Statements) ResolveStmt(s);

            _loopDepth = savedLoopDepth;
            _tryDepth = savedTryDepth;
            _functionDepth = savedFunctionDepth;
            _inConstructor = savedInConstructor;
            _current = saved;
        }

        /// <summary>Gemeinsame Body-Auflösung für `catch threads(...)`/`catch
        /// terminate(v)` (siehe Ast.CatchThreadsDecl/CatchTerminateDecl-Doku)
        /// - exakt dieselbe Isolation wie ResolveFireStmt (eigener, leerer
        /// globaler Scope, `return` verboten), aus demselben Grund: der
        /// Handler-Body läuft später als eigener, unabhängiger Proto,
        /// genestet in eine BELIEBIGE VM-Instanz (siehe VM.
        /// HandleDeliveredThreadException/RunTerminateHandlerIfAny), nicht im
        /// lexikalischen Kontext seiner Deklaration.</summary>
        /// <summary>Gemeinsame Body-Auflösung für `catch threads(...)`/`catch
        /// terminate(v)` (siehe Ast.CatchThreadsDecl/CatchTerminateDecl-Doku).
        ///
        /// WICHTIG, anders als bei ResolveFireStmt: der gebundene Parameter
        /// (`e`/`v`) muss LOKAL aufgelöst werden (`ResolvedRef.Local`), NICHT
        /// global (`ResolvedRef.Global`) - der Handler läuft NICHT auf einer
        /// eigenen, frischen VM-Instanz mit eigenem globalen Scope (wie ein
        /// fire-Block), sondern GENESTET INNERHALB der jeweils zustellenden
        /// VM-Instanz (siehe VM.HandleDeliveredThreadException/
        /// RunTerminateHandlerIfAny), die IHR EIGENES `_globalScope`-Feld
        /// weiterhin für das Hauptprogramm benutzt. Eine globale Auflösung
        /// des Parameters würde deshalb mit dessen SLOT 0 kollidieren (z.B.
        /// mit der ersten `var`-Deklaration des Hauptprogramms) - der
        /// Parameter braucht daher denselben Scope-Aufbau wie eine Lambda
        /// (`new ResolverScope(_globalScope)`, NICHT `isGlobal: true`): sieht
        /// die echten Globals zum NAMEN-Nachschlagen, wird selbst aber als
        /// LOKALE Variable von Tiefe 0 registriert - exakt das, was
        /// `handlerScope.DefineSlot(...)` in der VM zur Laufzeit befüllt.</summary>
        private void ResolveGlobalHandlerBody(string? varName, Stmt.BlockStmt body)
        {
            var saved = _current;
            _current = new ResolverScope(_globalScope);

            if (varName != null) Define(varName, body.Line);

            int savedLoopDepth = _loopDepth;
            int savedTryDepth = _tryDepth;
            int savedFunctionDepth = _functionDepth;
            bool savedInConstructor = _inConstructor;
            _loopDepth = 0;
            _tryDepth = 0;
            _functionDepth = 0;
            _inConstructor = false;

            foreach (var s in body.Statements) ResolveStmt(s);

            _loopDepth = savedLoopDepth;
            _tryDepth = savedTryDepth;
            _functionDepth = savedFunctionDepth;
            _inConstructor = savedInConstructor;
            _current = saved;
        }

        private void ResolveLambda(LambdaExpr lambda)
        {
            if (lambda.OnTarget != null)
                ResolveExpr(lambda.OnTarget);

            var saved = _current;
            _current = new ResolverScope(_globalScope);

            // Ein Lambda, das INNERHALB eines Konstruktors definiert wird, läuft
            // typischerweise erst SPÄTER (nach Abschluss der Konstruktion) -
            // 'this.readonlyFeld = ...' darin wäre daher nicht sicher als
            // "noch während der Konstruktion" einzustufen. Für die Dauer des
            // Lambda-Bodies also bewusst so behandeln, als wäre man NICHT im
            // Konstruktor, unabhängig vom umgebenden Kontext.
            bool savedInConstructor = _inConstructor;
            _inConstructor = false;

            // Standardwerte VOR dem Definieren der Parameter auflösen (siehe
            // ResolveParamDefaults-Kommentar) - der Scope hier ist noch leer
            // (nur global als Parent), also automatisch isoliert von den
            // eigenen Parametern.
            ValidateOptionalParamsAreTrailing(lambda.Params, lambda.Line);
            foreach (var p in lambda.Params)
                if (p.DefaultValue != null)
                    ResolveExpr(p.DefaultValue);

            foreach (var p in lambda.Params)
            {
                if (p.Type != null) ValidateTypeRef(p.Type, lambda.Line);
                ResolveArrayRanks(p.ArrayRanks);
                Define(p.Name, lambda.Line);
            }

            int savedLoopDepth = _loopDepth;
            int savedTryDepth = _tryDepth;
            _loopDepth = 0;
            _tryDepth = 0;

            _functionDepth++;
            foreach (var s in lambda.Body.Statements) ResolveStmt(s);
            _functionDepth--;

            _loopDepth = savedLoopDepth;
            _tryDepth = savedTryDepth;

            _inConstructor = savedInConstructor;
            _current = saved;
        }
    }
}
