using System.Collections.Generic;
using fire.Values;

namespace fire.Runtime
{
    /// <summary>
    /// Laufzeit-Gegenstück zu einem vom Resolver erkannten Scope-Knoten (Block,
    /// Funktion/Methode/Lambda-Body, globaler Scope). Variablen liegen slot-indiziert
    /// vor (Index entspricht exakt dem, was der Resolver für die jeweilige
    /// IdentifierExpr ermittelt hat - kein Namens-Lookup zur Laufzeit nötig).
    ///
    /// Scope ist gleichzeitig ein IOwner: Objektinstanzen, deren Owner dieser Scope
    /// ist, werden in <see cref="Release"/> kaskadierend zerstört, wenn der Scope
    /// verlassen wird (Block-/Funktionsende) - es sei denn, sie wurden vorher per
    /// TakeUpwards/TakeGlobal/TakeTo transferiert oder per return an den Parent-
    /// Scope weitergereicht (SPEC 2.3; das "return übergibt Ownership"-Verhalten
    /// wird vom Evaluator umgesetzt, indem er vor dem Release des Funktions-Scopes
    /// den Rückgabewert - falls es eine von diesem Scope besessene Objektinstanz
    /// ist - per TakeUpwards an den aufrufenden Scope überträgt).
    /// </summary>
    public sealed class Scope : IOwner
    {
        public Scope? Parent { get; }
        public bool IsGlobal { get; }

        // Bewusst NULL statt vorab angelegter leerer Listen (siehe
        // DefineSlot/AddOwned) - JEDE Blockausführung (z.B. jeder einzelne
        // Schleifendurchlauf, siehe Compiler.CompileScopedBody: ein
        // EnterScope/ExitScope-Paar PRO Iteration) legt sonst zwei leere
        // List<T>-Instanzen an, selbst wenn der Block gar keine lokale
        // Variable deklariert und kein Objekt besitzt (der häufigste Fall
        // bei einfachen Schleifenkörpern) - spart zwei von drei Allokationen
        // pro Scope in genau diesem, sehr heißen Pfad.
        private List<Value>? _slots;
        private List<ObjectInstance>? _owned;

        public Scope(Scope? parent, bool isGlobal = false)
        {
            Parent = parent;
            IsGlobal = isGlobal;
        }

        // -----------------------------------------------------------
        // Slot-Zugriff
        // -----------------------------------------------------------

        /// <summary>Legt einen neuen Slot an (Reihenfolge muss exakt der
        /// Deklarationsreihenfolge entsprechen, die der Resolver zugrunde gelegt
        /// hat) und gibt seinen Index zurück.</summary>
        public int DefineSlot(Value initialValue)
        {
            var slots = _slots ??= new List<Value>();
            slots.Add(initialValue);
            return slots.Count - 1;
        }

        /// <summary>GetSlot/SetSlot werden nur mit einem Index aufgerufen, der
        /// aus einer vorherigen DefineSlot-Reihenfolge stammt (siehe
        /// Resolver/Compiler - der Index ist zur Kompilierzeit fest bekannt) -
        /// `_slots` ist an dieser Stelle deshalb garantiert bereits belegt,
        /// kein Null-Check nötig (bewusst kein zusätzlicher Branch im Hot
        /// Path für einen Zustand, der bei korrekt kompiliertem Bytecode nie
        /// eintreten kann - ein `null`-Zugriff hier wäre ohnehin ein
        /// VM-/Compiler-Bug, siehe Values.VmInvariantViolationException-Doku
        /// für dieselbe Unterscheidung bei Value.RequireKind).</summary>
        public Value GetSlot(int index) => _slots![index];
        public void SetSlot(int index, Value value) => _slots![index] = value;

        /// <summary>Anzahl belegter Slots - für Debug-/Inspektionszwecke (siehe
        /// VM.DebugLocals), von der normalen Ausführung selbst nicht gebraucht.</summary>
        public int SlotCount => _slots?.Count ?? 0;

        /// <summary>Läuft `depth` Elternschritte nach oben - depth entspricht exakt
        /// dem, was der Resolver in ResolvedRef.Local(depth, slot) ermittelt hat.</summary>
        public Scope GetAncestor(int depth)
        {
            var scope = this;
            for (int i = 0; i < depth; i++)
                scope = scope.Parent!;
            return scope;
        }

        // -----------------------------------------------------------
        // IOwner
        // -----------------------------------------------------------
        public IReadOnlyList<ObjectInstance> OwnedObjects => (IReadOnlyList<ObjectInstance>?)_owned ?? System.Array.Empty<ObjectInstance>();
        public void AddOwned(ObjectInstance obj) => (_owned ??= new List<ObjectInstance>()).Add(obj);
        public void RemoveOwned(ObjectInstance obj) => _owned?.Remove(obj);

        /// <summary>Wird beim Verlassen des Scopes aufgerufen: zerstört
        /// kaskadierend alle noch von diesem Scope besessenen Objekte.</summary>
        public void Release(IDestructRunner runner)
        {
            if (_owned == null) return; // nichts zu tun - der häufigste Fall bei einfachen Blöcken/Schleifenkörpern
            // Kopie, da Destroy() während der Iteration _owned weiterer Objekte
            // verändern kann (verschachtelte Kaskaden).
            foreach (var obj in _owned.ToArray())
                obj.Destroy(runner);
            _owned.Clear();
        }
    }
}
